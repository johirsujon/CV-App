package me.johir.www.johirscv;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView career_objectives, computer_skills, language_skills, academic_information, extra_curriculam, projects, personal_details, permanent_address, refference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        assignValue();
        career_objectives.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CareerObjectives.class);
                startActivity(intent);
            }
        });

        computer_skills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GeneralComputerSkills.class);
                startActivity(intent);
            }
        });

        language_skills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, LanguagesSkills.class);
                startActivity(intent);

            }
        });


        academic_information.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AcademicInformation.class);
                startActivity(intent);
            }
        });

        extra_curriculam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ExtraCurriculam.class);
                startActivity(intent);
            }
        });


        projects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Projects.class);
                startActivity(intent);
            }
        });

        personal_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PersonalDetails.class);
                startActivity(intent);

            }
        });
        permanent_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, PermanentAddress.class);
                startActivity(intent);
            }
        });
        refference.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ReferenceName.class);
                startActivity(intent);
            }
        });




    }

   public void assignValue(){
        career_objectives = findViewById(R.id.career_objectives);
       computer_skills = findViewById(R.id.general_computer_skills);
       language_skills = findViewById(R.id.languages_skills);
       academic_information = findViewById(R.id.academic_information);
       extra_curriculam = findViewById(R.id.extra_curriculam);
       projects = findViewById(R.id.projects);
       personal_details = findViewById(R.id.personal_details);
       permanent_address = findViewById(R.id.permanent_address);
       refference = findViewById(R.id.reference);

    }
}
